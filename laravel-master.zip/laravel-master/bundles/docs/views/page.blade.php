@layout('docs::template')

@section('content')
	{{ $content }}
@endsection