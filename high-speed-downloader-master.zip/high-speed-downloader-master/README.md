百度网盘不限速下载器 2018年4月19日更新
=================
这是一款通过算法来提速的高速下载器，支持Windows和Mac。


新版本已经移除挖矿，依然免费使用！赞助作者维持项目。

微信二维码
<img src="https://img.hacpai.com/file/2018/04/bd899f8c255645e1aa251865d21ac6ae_2731524121462_pic.jpg" width=256 height=256 />

效果图
----
![7551513691037_.pic.jpg](https://img.hacpai.com/file/2017/12/7b7365edcfb848bcb3448d404b9bd440_7551513691037_pic.jpg)

使用方法
----
- 安装高速下载器客户端和浏览器插件
- 打开[百度网盘](https://pan.baidu.com/)点击高速下载即可

![image.png](https://img.hacpai.com/file/2017/12/68c0512566d747d6bc47a791aa7ed372_image.png)

安装说明
----

本软件需要安装浏览器插件和客户端

### 下载地址
- 微云：https://share.weiyun.com/2d1d66fb70779a7ee6938c102f25798f 密码：7vtB9P

### 浏览器插件安装
谷歌浏览器
<br/>打开谷歌浏览器地址输入chrome://extensions/并打开，把下载好的“新版谷歌浏览器插件.crx”从文件夹里直接拖到“扩展程序”界面中。
![image.png](https://img.hacpai.com/file/2017/12/1e8b0fbac8514920931918731ac966bd_image.png)

360等浏览器
<br/>双击“360等浏览器插件.crx”安装或者拖进浏览器中

### 客户端安装
- mac:正常安装即可。
- windows免安装:下载解压打开downloader.exe

常见问题
----
mac上来自身份不明的开发者

![image.png](https://img.hacpai.com/file/2017/12/26f3bac005be4dfcae8053adcea93da3_image.png)

参考https://www.macdo.cn/925.html




