<template>
  <div id="app">
<router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'electorn-wifi',
  }
</script>

<style>
  /* CSS */
</style>
